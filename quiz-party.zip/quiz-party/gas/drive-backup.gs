/**
 * EGクイズアプリ：アンケート画像のGoogleドライブ・バックアップ
 *
 * 【スクリプトプロパティ】（プロジェクトの設定 → スクリプト プロパティ）
 *   FOLDER_ID … 保存先フォルダのID（ドライブのフォルダURL「folders/」のあとの文字列）
 *   TOKEN     … 合言葉（問題作成画面に入力するものと同じ文字列）
 *
 * 【デプロイ】
 *   デプロイ → 新しいデプロイ → 種類「ウェブアプリ」
 *   次のユーザーとして実行：自分 ／ アクセスできるユーザー：全員
 *   → 表示された「ウェブアプリのURL」を問題作成画面に入力
 *
 * 保存したファイルは共有設定をしません（フォルダの持ち主だけが見られます）。
 */

/** アプリからの送信を受け取る */
function doPost(e) {
  try {
    const props = PropertiesService.getScriptProperties();
    const folderId = props.getProperty('FOLDER_ID');
    const token = props.getProperty('TOKEN');
    if (!folderId || !token) return json_({ ok: false, error: 'スクリプトプロパティ FOLDER_ID と TOKEN を設定してください' });

    const body = JSON.parse(e.postData.contents || '{}');
    if (body.token !== token) return json_({ ok: false, error: '合言葉が違います' });

    const root = DriveApp.getFolderById(folderId);

    // 接続テスト
    if (body.action === 'ping') return json_({ ok: true, folder: root.getName() });

    // 画像の保存
    if (body.action === 'save') {
      const eventFolder = getOrCreateFolder_(root, cleanName_(body.event || '開催名なし'));
      const fileName = cleanName_(body.fileName || 'image.jpg');

      // 同じ名前のファイルがあれば保存しない（二重保存の防止）
      const same = eventFolder.getFilesByName(fileName);
      if (same.hasNext()) return json_({ ok: true, id: same.next().getId(), skipped: true });

      const m = String(body.data || '').match(/^data:([^;]+);base64,(.+)$/);
      if (!m) return json_({ ok: false, error: '画像データの形式が正しくありません' });
      const blob = Utilities.newBlob(Utilities.base64Decode(m[2]), m[1], fileName);
      const file = eventFolder.createFile(blob);
      file.setDescription([body.person || '', body.question || '', body.imageId || ''].join(' / '));
      return json_({ ok: true, id: file.getId() });
    }

    return json_({ ok: false, error: '不明な操作です' });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message || err) });
  }
}

/** ブラウザで直接開いたとき用の確認表示 */
function doGet() {
  return json_({ ok: true, message: 'EGクイズアプリ バックアップ用のウェブアプリです' });
}

/** フォルダがあれば使い、なければ作る */
function getOrCreateFolder_(parent, name) {
  const it = parent.getFoldersByName(name);
  return it.hasNext() ? it.next() : parent.createFolder(name);
}

/** ファイル名・フォルダ名に使えない文字を置き換える */
function cleanName_(s) {
  return String(s).replace(/[\\/:*?"<>|#\n\r\t]/g, '_').slice(0, 120);
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** 初回だけ実行：ドライブへのアクセスを許可するための関数（中身は何もしません） */
function authorize() {
  const id = PropertiesService.getScriptProperties().getProperty('FOLDER_ID');
  if (id) Logger.log('保存先フォルダ：' + DriveApp.getFolderById(id).getName());
  else Logger.log('スクリプトプロパティ FOLDER_ID を設定してください');
}
